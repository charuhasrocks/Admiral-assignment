import Products from "./product";
export default Products;
