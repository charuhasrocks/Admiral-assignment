import Card from "./mediaCard";
export default Card;
